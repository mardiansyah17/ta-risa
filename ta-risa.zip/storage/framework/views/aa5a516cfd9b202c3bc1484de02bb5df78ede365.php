<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-3">
        <a href="<?php echo e(route('venue.create')); ?>" class="btn btn-primary">Tambah</a>
        <table class="table table-zebra">
            <!-- head -->
            <thead>
            <tr>
                <th>No</th>
                <th>Venue</th>
                <th>type</th>
                <th>kapasistas</th>
                <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
            <!-- row 1 -->
            <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($loop->iteration); ?></th>
                    <th><?php echo e($venue->title); ?></th>
                    <th><?php echo e($venue->type); ?></th>
                    <th><?php echo e($venue->kapasistas); ?></th>
                    <th>
                        <form class="inline" action="<?php echo e(route('venue.destroy',$venue->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Hapus</button>
                        </form>
                        -
                        <a href="<?php echo e(route('venue.edit',$venue->id)); ?>">edit</a>
                        -
                        <a href="<?php echo e(route('venue.harga',$venue->id)); ?>">Harga</a>

                    </th>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/venue/kelolavenue.blade.php ENDPATH**/ ?>