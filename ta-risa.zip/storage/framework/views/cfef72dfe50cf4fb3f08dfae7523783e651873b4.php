<img src="<?php echo e(asset('images/logo-jakabaring.png')); ?>" alt="">
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/components/application-logo.blade.php ENDPATH**/ ?>