<div class="card w-96 bg-base-100 shadow-xl image-full">
    <figure><img src="<?php echo e(asset('lapanganbola.jpeg')); ?>" alt="Shoes"/></figure>
    <div class="card-body">
        <h2 class="card-title"><?php echo e($title); ?></h2>
        <p><?php echo e($desc); ?></p>
        <div class="card-actions justify-end">
            <a href="<?php echo e(route('venue.show',$id)); ?>" class="btn btn-primary">Pesan sekarang</a>
        </div>
    </div>
</div>
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/components/card.blade.php ENDPATH**/ ?>