<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="border border-gray-200 shadow-md rounded-md w-4/5 p-3 mx-auto mt-5">
        <div class="">
            <div class="flex items-center space-x-3">
                <span>Kepada  </span>
                <span>:</span>
                <span><?php echo e($pemesanan->user->name); ?></span>
            </div>
            <div class="flex items-center space-x-3">
                <span>Kode transaksi  </span>
                <span>:</span>
                <span><?php echo e($pemesanan->kode_transaksi); ?></span>
            </div>

            <div class="flex items-center space-x-3">
                <span>Tanggal  </span>
                <span>:</span>
                <span><?php echo e($pemesanan->sesi->tanggal); ?></span>
            </div>
            <div class="flex items-center space-x-3">
                <span>Sesi  </span>
                <span>:</span>
                <span><?php echo e($pemesanan->sesi->jam_mulai); ?> - <?php echo e($pemesanan->sesi->jam_selesai); ?></span>
            </div>
            <div class="flex items-center space-x-3">
                <span>Status  </span>
                <span>:</span>
                <span
                    class="badge text-slate-100 <?php echo e($pemesanan->statis == "belum bayar"?"badge-error":"badge-success"); ?>"><?php echo e($pemesanan->status); ?></span>
            </div>
            <?php if($pemesanan->bukti_pembayaran): ?>
                <a href="/storage/<?php echo e($pemesanan->bukti_pembayaran); ?>" class="text-blue-500">Lihat bukti
                    pembayaran</a>
            <?php else: ?>
                <p>Pastikan anda membayar ke BNI dengan nomor rekning 3424234091239180981 dengan total
                    Rp<?php echo e($pemesanan->sesi->price->price); ?></p>
            <?php endif; ?>
        </div>
        <div class="overflow-x-auto">
            <table class="table">
                <!-- head -->
                <thead>
                <tr>
                    <th>Kode barang</th>
                    <th>Nama</th>
                    <th>Kts</th>
                    <th>Harga</th>
                </tr>
                </thead>
                <tbody>
                <!-- row 1 -->
                <tr>
                    <th>1</th>
                    <td><?php echo e($pemesanan->venue->title); ?></td>
                    <td>1</td>
                    <td> Rp<?php echo e($pemesanan->sesi->price->price); ?></td>
                </tr>
                </tbody>
            </table>
        </div>
        <form action="<?php echo e(route('pesanan.bayar',$pemesanan->id)); ?>" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
            <input type="file" class="file-input w-full max-w-xs" name="bukti_bayar" id="bukti_bayar_input"/>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary" id="upload_button" disabled>Upload bukti
                    pembayaran
                </button>
            </div>
        </form>
    </div>
    <script>
        const bukti_bayar_input = document.getElementById('bukti_bayar_input');
        const upload_button = document.getElementById('upload_button');
        bukti_bayar_input.addEventListener('change', function () {
            upload_button.removeAttribute('disabled');
        })
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/pesanan/detail-pesanan.blade.php ENDPATH**/ ?>