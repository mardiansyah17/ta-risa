<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-3">
        <form class="flex space-x-3">

            <div class="flex items-center space-x-3">
                <label for="start">Start date:</label>
                <input name="start_date" type="date" id="start">
            </div>
            <div class="flex items-center space-x-3">
                <label for="start">End date:</label>
                <input name="end_date" type="date" id="start">
            </div>
            <select name="venue" class="select select-primary w-full max-w-xs">
                <option disabled selected>Pilih venue</option>
                <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($venue->id); ?>"><?php echo e($venue->title); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit" class="btn btn-primary">Filter</button>
            <a class="btn btn-primary"
               href="<?php echo e(route('admin.download-laporan', ['start_date' => request()->query('start_date'), 'end_date' => request()->query('end_date'), 'venue' => request()->query('venue')])); ?>">Download
                Laporan</a>

        </form>
        <div class="overflow-x-auto">
            <?php echo $__env->make('components.table-laporan',["pesanans"=>$pesanans], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/admin/index.blade.php ENDPATH**/ ?>