<!DOCTYPE html>
<html data-theme="light" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>


</head>

<body class="antialiased">

<div class="">
    <?php echo $__env->yieldContent('content'); ?>
</div>


</body>

</html>
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/welcome.blade.php ENDPATH**/ ?>