<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="p-3">
        <img src="<?php echo e(asset("/images/jakabaring.jpg")); ?>" class="h-[20rem] bg-cover  w-4/5 mx-auto rounded-md">
        <div class="flex space-x-3 mt-5">
            <div class="basis-[70%]">

                <h2 class="mt-4"><?php echo e($venues->title); ?></h2>
                <p><?php echo e($venues->description); ?></p>
            </div>
            <div class="p-3 bg-white border border-gray-200 shadow-md rounded-md basis-[30%]">
                <h3 class="text-xl mb-3">Pesan sekarang</h3>
                <?php $__currentLoopData = $venues->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="bg-green-500 p-1 text-white  rounded-md "><?php echo e($price->price); ?></span>
                    <?php $__currentLoopData = $price->sesi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-3"><?php echo e($sesi->jam_mulai); ?> - <?php echo e($sesi->jam_selesai); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('venues.pesan',$venues->id)); ?>"
                   class="bg-blue-500 w-full rounded-md text-white py-2 mt-3 block text-center">Pesan</a>
            </div>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/venue/detailvenue.blade.php ENDPATH**/ ?>