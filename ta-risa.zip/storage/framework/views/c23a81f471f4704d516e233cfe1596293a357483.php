<?php $__env->startSection('content'); ?>
    tes
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/transaksi/transaksi.blade.php ENDPATH**/ ?>