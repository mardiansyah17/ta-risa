<div class="navbar  absolute top-0 left-0 right-0 ">
    <div class="flex-1">
        <a class="btn btn-ghost normal-case text-xl">JAKABARING SPORT CITY</a>
    </div>
    <div class="flex-none">
        <ul class="menu menu-horizontal px-1">
            <?php if(auth()->check()): ?>
                <?php if(auth()->user()->role == 'admin'): ?>
                    <li><a href="">Kelola venue</a></li>
                <?php else: ?>
                    <li><a>Cari</a></li>

                <?php endif; ?>
                <li><a href="<?php echo e(route('transaksi.index')); ?>">Pemesanan</a></li>
                <li><a>Logout</a></li>
            <?php else: ?>
                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
            <?php endif; ?>

        </ul>
    </div>
</div>
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/components/navbar.blade.php ENDPATH**/ ?>