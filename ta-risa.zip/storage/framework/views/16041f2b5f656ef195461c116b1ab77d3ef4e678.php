<h3 class="hidden">Laporan pemesanan</h3>
<table class="table table-zebra">

    <thead>
    <tr>
        <th>No</th>
        <th>Tanggal</th>
        <th>Pemesan</th>
        <th>NIK</th>
        <th>Venue</th>
        <th>Jadwal</th>
        <th>Harga</th>
    </tr>
    </thead>
    <tbody>
    <!-- row 1 -->
    <div class="hidden">
        <?php echo e($total = 0); ?>

    </div>
    <?php $__currentLoopData = $pesanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($loop->iteration); ?></th>
            <th><?php echo e($pesanan->created_at); ?></th>
            <th><?php echo e($pesanan->user->name); ?></th>
            <th><?php echo e($pesanan->user->nik); ?></th>
            <th><?php echo e($pesanan->venue->title); ?></th>
            <th><?php echo e($pesanan->sesi->jam_mulai); ?>

                - <?php echo e($pesanan->sesi->jam_selesai); ?> <?php echo e($pesanan->sesi->tanggal); ?></th>
            <th>Rp. <?php echo number_format($pesanan->sesi->price->price,0,',','.'); ?></th>
        </tr>
        <span hidden="hidden">   <?php echo e($total += $pesanan->sesi->price->price); ?></span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th></th>
        <th>Total</th>
        <th>Rp. <?php echo number_format($total,0,',','.'); ?></th>
    </tr>
    </tbody>
</table>

<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/components/table-laporan.blade.php ENDPATH**/ ?>