<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h2 class="">Pilih sesi</h2>
    <div class="flex space-x-3">
        <?php echo $__env->make('components.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="w-[30%]">
            <div class="overflow-x-auto mb-3">
                <table class="table">
                    <!-- head -->
                    <thead class="">
                    <tr>
                        <th>Venue</th>
                        <th>Type</th>
                        <th>Price</th>
                    </tr>
                    </thead>
                    <tbody>
                    <!-- row 1 -->
                    <tr>
                        <td><?php echo e($venue->title); ?></td>
                        <td><?php echo e($venue->type); ?></td>
                        <td id="price"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <form action="<?php echo e(route('venues.pesan',$venue->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="sesi" id="sesiInput">
                <button type="submit" class="btn btn-primary">Pesan</button>
            </form>
        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\Project coding\laravel\ta-risa\resources\views/venue/pesanvenue.blade.php ENDPATH**/ ?>