@extends('welcome')
@section('content')
    tes
@endsection
